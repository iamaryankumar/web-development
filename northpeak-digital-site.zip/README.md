# NorthPeak Digital — One-Page Agency Site

## What's in here
- `index.html` — the whole site. No build step, no dependencies except Google Fonts (loaded via CDN link tags in the <head>).

## Deploy it (pick one)
- **Netlify Drop** (fastest, no account needed for first drop): go to app.netlify.com/drop, drag `index.html` onto the page. Live in ~20 seconds.
- **Vercel**: `npx vercel --prod` from this folder (needs a free Vercel account/login).
- **GitHub Pages**: push this folder to a public repo, enable Pages on the main branch root.

## Before you submit
- Rewrite the copy in your own words — headline, service descriptions, testimonials are all placeholder text I wrote, not real client quotes. Using them as-is is the "hand in what a model gives you on the first prompt" problem the brief warns against.
- Change at least one real design decision (accent color, type pairing, or the contour-texture motif) so it's demonstrably yours, and be ready to explain why in the Loom.
- Run Lighthouse yourself after deploying (Chrome DevTools → Lighthouse tab) and screenshot both Performance and Accessibility. I have not verified an actual score — I only built with the common blockers (image weight, font loading, motion) removed in advance.
- Push the final version to a public GitHub repo — that's a required deliverable and something I can't do on your behalf.

## Design notes (for your own Loom / changelog)
- Palette: cold paper background (#F2F4F2), deep slate ink (#1B2B2E), glacier blue (#3E6E86), trail-blaze orange (#E0602A) — chosen because the brand name is NorthPeak, not a generic default.
- Type: Space Grotesk (display), Inter (body), JetBrains Mono (data labels / elevation numbers) — deliberately avoids the cream+terracotta and black+neon AI-design defaults.
- No raster images anywhere — all visual texture is CSS (the contour-line pattern in the hero). This is also the main reason the Lighthouse performance floor should be high before you've done any manual optimization.
- Known cost: `backdrop-filter: blur()` on the sticky header is the most likely thing to cost you points on older browsers/Safari — first place to look if Performance isn't 90+.
